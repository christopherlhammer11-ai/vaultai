# VaultAI

**Your Personal AI Operating System**

One encrypted vault. Every AI model. Store your context, preferences, projects, and goals. Use with Claude, GPT, or any model.

## Features

### 🔐 Encrypted & Private
- AES-256 encryption with password protection
- All data stored locally in your browser
- No accounts, no servers, no tracking
- Export/import your vault anytime

### 🤖 Multi-Model Support
- Claude (Sonnet, Haiku)
- GPT (4o, 4o-mini)
- Switch models instantly
- Your vault context included automatically

### 🧠 Deep Context
- **Memories** — Facts, preferences, constraints, goals
- **Projects** — What you're working on
- **People** — Key relationships and context
- **Behavior** — How you want AI to respond

### 💰 Flexible Pricing
- **Free:** Bring your own API keys — unlimited use
- **Pro ($15/mo):** Use VaultAI's keys — no setup required

## Quick Start

```bash
# Install dependencies
npm install

# Add your API keys (optional - for VaultAI-provided keys)
cp .env.example .env.local
# Edit .env.local with your keys

# Run development server
npm run dev

# Open http://localhost:3000
```

## Environment Variables

For VaultAI to provide API keys to users:

```env
OPENAI_API_KEY=sk-your-openai-key
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key
```

Users can also add their own keys in the app settings for unlimited free use.

## Project Structure

```
src/
├── app/
│   ├── page.tsx          # Landing page
│   ├── setup/            # Onboarding flow
│   ├── vault/            # Vault management
│   ├── chat/             # Multi-model chat
│   └── api/chat/         # Chat API with tiered keys
├── lib/
│   ├── types.ts          # Vault schema & tiers
│   ├── storage.ts        # LocalStorage + encryption
│   ├── encryption.ts     # AES-256 utilities
│   └── prompt.ts         # System prompt generator
└── public/
    ├── manifest.json     # PWA manifest
    └── icon.svg          # App icon
```

## PWA Support

VaultAI is a Progressive Web App:
- Install on home screen (mobile)
- Native app-like experience
- Works offline (vault data)

## Deployment

### Vercel (Recommended)

```bash
vercel
```

Add environment variables in Vercel dashboard.

## Tech Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Framer Motion
- crypto-js (AES-256)
- OpenAI SDK
- Anthropic SDK

## License

MIT
