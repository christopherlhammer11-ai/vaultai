import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";

export async function POST(request: NextRequest) {
  try {
    const { provider, apiKey } = await request.json();

    if (!provider || !apiKey) {
      return NextResponse.json({ valid: false, error: "Missing provider or API key" });
    }

    if (provider === "openai") {
      const openai = new OpenAI({ apiKey });
      // Make a simple request to verify the key
      await openai.models.list();
      return NextResponse.json({ valid: true });
    }

    if (provider === "anthropic") {
      const anthropic = new Anthropic({ apiKey });
      // Make a simple request to verify the key
      await anthropic.messages.create({
        model: "claude-sonnet-4-20250514",
        max_tokens: 10,
        messages: [{ role: "user", content: "Hi" }],
      });
      return NextResponse.json({ valid: true });
    }

    return NextResponse.json({ valid: false, error: "Unknown provider" });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ valid: false, error: message });
  }
}
