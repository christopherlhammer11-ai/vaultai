import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";

// VaultAI's API keys (from environment)
const VAULTAI_OPENAI_KEY = process.env.OPENAI_API_KEY;
const VAULTAI_ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;

export async function POST(request: NextRequest) {
  try {
    const { messages, model, apiKeys, systemPrompt, useVaultAIKeys } = await request.json();

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "Messages are required" }, { status: 400 });
    }

    // Determine provider
    const isOpenAI = model.startsWith("gpt");
    const isAnthropic = model.startsWith("claude");

    // Determine which API key to use
    let apiKey: string | undefined;
    let usingVaultAIKey = false;

    if (isOpenAI) {
      // Priority: user's key > VaultAI's key (if enabled)
      if (apiKeys?.openai) {
        apiKey = apiKeys.openai;
      } else if (useVaultAIKeys && VAULTAI_OPENAI_KEY) {
        apiKey = VAULTAI_OPENAI_KEY;
        usingVaultAIKey = true;
      }

      if (!apiKey) {
        return NextResponse.json({ 
          error: "No OpenAI API key available. Add your own key in Settings, or upgrade to VaultAI Pro.",
          code: "NO_API_KEY"
        }, { status: 400 });
      }

      const openai = new OpenAI({ apiKey });

      const modelMap: Record<string, string> = {
        "gpt-4o": "gpt-4o",
        "gpt-4o-mini": "gpt-4o-mini",
      };

      const completion = await openai.chat.completions.create({
        model: modelMap[model] || "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages.map((m: { role: string; content: string }) => ({
            role: m.role as "user" | "assistant",
            content: m.content,
          })),
        ],
        max_tokens: 2048,
      });

      return NextResponse.json({
        content: completion.choices[0]?.message?.content || "",
        tokensUsed: completion.usage?.total_tokens,
        usingVaultAIKey,
      });
    }

    if (isAnthropic) {
      // Priority: user's key > VaultAI's key (if enabled)
      if (apiKeys?.anthropic) {
        apiKey = apiKeys.anthropic;
      } else if (useVaultAIKeys && VAULTAI_ANTHROPIC_KEY) {
        apiKey = VAULTAI_ANTHROPIC_KEY;
        usingVaultAIKey = true;
      }

      if (!apiKey) {
        return NextResponse.json({ 
          error: "No Anthropic API key available. Add your own key in Settings, or use VaultAI's included keys.",
          code: "NO_API_KEY"
        }, { status: 400 });
      }

      const anthropic = new Anthropic({ apiKey });

      const modelMap: Record<string, string> = {
        "claude-sonnet": "claude-sonnet-4-20250514",
        "claude-haiku": "claude-haiku-3-5-20241022",
      };

      const response = await anthropic.messages.create({
        model: modelMap[model] || "claude-sonnet-4-20250514",
        max_tokens: 2048,
        system: systemPrompt,
        messages: messages.map((m: { role: string; content: string }) => ({
          role: m.role as "user" | "assistant",
          content: m.content,
        })),
      });

      const textContent = response.content.find(c => c.type === "text");
      return NextResponse.json({
        content: textContent?.type === "text" ? textContent.text : "",
        tokensUsed: response.usage?.input_tokens + response.usage?.output_tokens,
        usingVaultAIKey,
      });
    }

    return NextResponse.json({ error: "Unknown model" }, { status: 400 });
  } catch (error) {
    console.error("Chat API error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    
    // Handle specific API errors
    if (message.includes("401") || message.includes("invalid_api_key")) {
      return NextResponse.json({ 
        error: "Invalid API key. Please check your key in Settings.",
        code: "INVALID_API_KEY"
      }, { status: 401 });
    }
    
    if (message.includes("429") || message.includes("rate_limit")) {
      return NextResponse.json({ 
        error: "Rate limit exceeded. Please try again in a moment.",
        code: "RATE_LIMIT"
      }, { status: 429 });
    }

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
