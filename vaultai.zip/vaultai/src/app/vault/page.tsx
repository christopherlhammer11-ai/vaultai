"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { VaultV2, defaultVault, generateId, Project, Person, Memory, MemoryCategory, ModelType, MODEL_INFO } from "@/lib/types";
import { loadVault, saveVault, getStorageState, exportVault, clearVault } from "@/lib/storage";
import { generateSystemPrompt, estimateTokens } from "@/lib/prompt";

type Tab = "overview" | "memories" | "projects" | "people" | "settings" | "prompt";

export default function VaultPage() {
  const router = useRouter();
  const [vault, setVault] = useState<VaultV2 | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [password, setPassword] = useState("");
  const [isLocked, setIsLocked] = useState(false);
  const [unlockError, setUnlockError] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showAddMemory, setShowAddMemory] = useState(false);
  const [showAddProject, setShowAddProject] = useState(false);
  const [showAddPerson, setShowAddPerson] = useState(false);

  useEffect(() => {
    const state = getStorageState();
    if (!state.hasVault) {
      router.push("/setup");
      return;
    }
    if (state.isEncrypted) {
      setIsLocked(true);
    } else {
      const loaded = loadVault();
      if (loaded) setVault(loaded);
    }
  }, [router]);

  const handleUnlock = () => {
    const loaded = loadVault(password);
    if (loaded) {
      setVault(loaded);
      setIsLocked(false);
      setUnlockError(false);
    } else {
      setUnlockError(true);
    }
  };

  const handleSave = () => {
    if (!vault) return;
    const state = getStorageState();
    saveVault(vault, state.isEncrypted ? password : undefined);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const updateVault = (updates: Partial<VaultV2>) => {
    if (!vault) return;
    setVault({ ...vault, ...updates });
  };

  const addMemory = (content: string, category: MemoryCategory, importance: "high" | "medium" | "low") => {
    if (!vault) return;
    const memory: Memory = {
      id: generateId(),
      content,
      category,
      importance,
      createdAt: new Date().toISOString(),
      source: "manual",
    };
    updateVault({ memories: [...vault.memories, memory] });
  };

  const deleteMemory = (id: string) => {
    if (!vault) return;
    updateVault({ memories: vault.memories.filter(m => m.id !== id) });
  };

  const addProject = (project: Omit<Project, "id" | "createdAt" | "updatedAt">) => {
    if (!vault) return;
    const newProject: Project = {
      ...project,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    updateVault({ projects: [...vault.projects, newProject] });
  };

  const deleteProject = (id: string) => {
    if (!vault) return;
    updateVault({ projects: vault.projects.filter(p => p.id !== id) });
  };

  const addPerson = (person: Omit<Person, "id" | "createdAt">) => {
    if (!vault) return;
    const newPerson: Person = {
      ...person,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    updateVault({ people: [...vault.people, newPerson] });
  };

  const deletePerson = (id: string) => {
    if (!vault) return;
    updateVault({ people: vault.people.filter(p => p.id !== id) });
  };

  // Lock screen
  if (isLocked) {
    return (
      <main className="lock-screen min-h-screen flex items-center justify-center px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm text-center">
          <div className="w-16 h-16 rounded-2xl bg-vault-surface border border-vault-border flex items-center justify-center mx-auto mb-6">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-vault-accent">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0110 0v4" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold mb-2">Vault Locked</h1>
          <p className="text-vault-text-dim mb-6">Enter your password to unlock</p>
          <input
            type="password"
            value={password}
            onChange={e => { setPassword(e.target.value); setUnlockError(false); }}
            onKeyDown={e => e.key === "Enter" && handleUnlock()}
            placeholder="Password"
            className="vault-input w-full px-4 py-3 rounded-xl mb-4"
            autoFocus
          />
          {unlockError && <p className="text-red-400 text-sm mb-4">Incorrect password</p>}
          <button onClick={handleUnlock} className="vault-btn w-full py-3 rounded-xl">Unlock</button>
        </motion.div>
      </main>
    );
  }

  if (!vault) {
    return <main className="min-h-screen flex items-center justify-center"><div className="spinner w-8 h-8" /></main>;
  }

  const systemPrompt = generateSystemPrompt(vault);
  const promptTokens = estimateTokens(systemPrompt);

  return (
    <main className="min-h-screen pb-20">
      {/* Header */}
      <header className="px-6 py-4 border-b border-vault-border sticky top-0 bg-vault-bg/95 backdrop-blur-lg z-40">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-vault-accent">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0110 0v4" />
            </svg>
            <span className="font-semibold">Preference Vault</span>
            {vault.isEncrypted && (
              <span className="encrypted-badge ml-2">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                </svg>
                Encrypted
              </span>
            )}
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/chat" className="vault-btn-secondary px-4 py-2 rounded-lg text-sm">Chat</Link>
            <button onClick={handleSave} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${saved ? "bg-vault-accent text-vault-bg" : "vault-btn"}`}>
              {saved ? "Saved!" : "Save"}
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="px-6 py-4 border-b border-vault-border">
        <div className="max-w-6xl mx-auto flex gap-2 overflow-x-auto">
          {[
            { id: "overview", label: "Overview" },
            { id: "memories", label: `Memories (${vault.memories.length})` },
            { id: "projects", label: `Projects (${vault.projects.length})` },
            { id: "people", label: `People (${vault.people.length})` },
            { id: "prompt", label: "System Prompt" },
            { id: "settings", label: "Settings" },
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as Tab)} className={`vault-tab whitespace-nowrap ${activeTab === tab.id ? "active" : ""}`}>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Overview Tab */}
        {activeTab === "overview" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="vault-card rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4">Identity</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">Name</label>
                  <input type="text" value={vault.identity.name} onChange={e => updateVault({ identity: { ...vault.identity, name: e.target.value } })} className="vault-input w-full px-3 py-2 rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">Role</label>
                  <input type="text" value={vault.identity.role} onChange={e => updateVault({ identity: { ...vault.identity, role: e.target.value } })} className="vault-input w-full px-3 py-2 rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">Company</label>
                  <input type="text" value={vault.identity.company || ""} onChange={e => updateVault({ identity: { ...vault.identity, company: e.target.value } })} className="vault-input w-full px-3 py-2 rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">Location</label>
                  <input type="text" value={vault.identity.location} onChange={e => updateVault({ identity: { ...vault.identity, location: e.target.value } })} className="vault-input w-full px-3 py-2 rounded-lg" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm text-vault-text-dim mb-1">Bio</label>
                  <textarea value={vault.identity.bio} onChange={e => updateVault({ identity: { ...vault.identity, bio: e.target.value } })} rows={2} className="vault-input w-full px-3 py-2 rounded-lg resize-none" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="vault-card rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-vault-accent">{vault.memories.length}</div>
                <div className="text-sm text-vault-text-dim">Memories</div>
              </div>
              <div className="vault-card rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-vault-accent">{vault.projects.length}</div>
                <div className="text-sm text-vault-text-dim">Projects</div>
              </div>
              <div className="vault-card rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-vault-accent">{vault.people.length}</div>
                <div className="text-sm text-vault-text-dim">People</div>
              </div>
              <div className="vault-card rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-vault-accent">{promptTokens}</div>
                <div className="text-sm text-vault-text-dim">Prompt Tokens</div>
              </div>
            </div>

            <div className="vault-card rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4">AI Behavior</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">Response Style</label>
                  <select value={vault.behavior.answerMode} onChange={e => updateVault({ behavior: { ...vault.behavior, answerMode: e.target.value as any } })} className="vault-input w-full px-3 py-2 rounded-lg">
                    <option value="short">Short and direct</option>
                    <option value="steps">Step-by-step</option>
                    <option value="deep">Deep explanations</option>
                    <option value="adaptive">Adaptive</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">Tone</label>
                  <select value={vault.behavior.tone} onChange={e => updateVault({ behavior: { ...vault.behavior, tone: e.target.value as any } })} className="vault-input w-full px-3 py-2 rounded-lg">
                    <option value="direct">Direct</option>
                    <option value="friendly">Friendly</option>
                    <option value="formal">Formal</option>
                    <option value="playful">Playful</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="vault-card rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4">Definition of Success</h2>
              <textarea
                value={vault.success.definition}
                onChange={e => updateVault({ success: { ...vault.success, definition: e.target.value } })}
                placeholder="What should AI do better than anything else for you?"
                rows={2}
                className="vault-input w-full px-3 py-2 rounded-lg resize-none"
              />
            </div>
          </motion.div>
        )}

        {/* Memories Tab */}
        {activeTab === "memories" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold">Memories</h2>
                <p className="text-vault-text-dim text-sm">Things you've told your vault about yourself</p>
              </div>
              <button onClick={() => setShowAddMemory(true)} className="vault-btn px-4 py-2 rounded-lg text-sm">+ Add Memory</button>
            </div>

            {vault.memories.length === 0 ? (
              <div className="vault-card rounded-2xl p-12 text-center">
                <p className="text-vault-text-dim mb-4">No memories yet. Add information about yourself.</p>
                <button onClick={() => setShowAddMemory(true)} className="vault-btn px-4 py-2 rounded-lg">Add Your First Memory</button>
              </div>
            ) : (
              <div className="space-y-3">
                {vault.memories.map(memory => (
                  <div key={memory.id} className="vault-card rounded-xl p-4 flex justify-between items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`vault-badge ${memory.importance === "high" ? "vault-badge-green" : memory.importance === "medium" ? "vault-badge-yellow" : "vault-badge-gray"}`}>
                          {memory.category}
                        </span>
                        <span className="text-xs text-vault-text-muted">{new Date(memory.createdAt).toLocaleDateString()}</span>
                      </div>
                      <p className="text-sm">{memory.content}</p>
                    </div>
                    <button onClick={() => deleteMemory(memory.id)} className="text-vault-text-dim hover:text-red-400 transition-colors">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Projects Tab */}
        {activeTab === "projects" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold">Projects</h2>
                <p className="text-vault-text-dim text-sm">Things you're working on</p>
              </div>
              <button onClick={() => setShowAddProject(true)} className="vault-btn px-4 py-2 rounded-lg text-sm">+ Add Project</button>
            </div>

            {vault.projects.length === 0 ? (
              <div className="vault-card rounded-2xl p-12 text-center">
                <p className="text-vault-text-dim mb-4">No projects yet. Add what you're working on.</p>
                <button onClick={() => setShowAddProject(true)} className="vault-btn px-4 py-2 rounded-lg">Add Your First Project</button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {vault.projects.map(project => (
                  <div key={project.id} className="vault-card rounded-xl p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold">{project.name}</h3>
                      <div className="flex items-center gap-2">
                        <span className={`vault-badge ${project.status === "active" ? "vault-badge-green" : project.status === "paused" ? "vault-badge-yellow" : "vault-badge-gray"}`}>
                          {project.status}
                        </span>
                        <button onClick={() => deleteProject(project.id)} className="text-vault-text-dim hover:text-red-400">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                      </div>
                    </div>
                    <p className="text-sm text-vault-text-dim mb-3">{project.description}</p>
                    {project.goals.length > 0 && (
                      <div className="text-xs text-vault-text-muted">
                        Goals: {project.goals.join(", ")}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* People Tab */}
        {activeTab === "people" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold">People</h2>
                <p className="text-vault-text-dim text-sm">Key people AI should know about</p>
              </div>
              <button onClick={() => setShowAddPerson(true)} className="vault-btn px-4 py-2 rounded-lg text-sm">+ Add Person</button>
            </div>

            {vault.people.length === 0 ? (
              <div className="vault-card rounded-2xl p-12 text-center">
                <p className="text-vault-text-dim mb-4">No people added yet.</p>
                <button onClick={() => setShowAddPerson(true)} className="vault-btn px-4 py-2 rounded-lg">Add Someone</button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {vault.people.map(person => (
                  <div key={person.id} className="vault-card rounded-xl p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold">{person.name}</h3>
                      <button onClick={() => deletePerson(person.id)} className="text-vault-text-dim hover:text-red-400">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                      </button>
                    </div>
                    <div className="text-sm text-vault-accent mb-2">{person.relationship}</div>
                    <p className="text-sm text-vault-text-dim">{person.context}</p>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* System Prompt Tab */}
        {activeTab === "prompt" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold">System Prompt</h2>
                <p className="text-vault-text-dim text-sm">Generated from your vault — copy this into any AI</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm text-vault-text-dim">{promptTokens} tokens</span>
                <button
                  onClick={() => navigator.clipboard.writeText(systemPrompt)}
                  className="vault-btn px-4 py-2 rounded-lg text-sm"
                >
                  Copy
                </button>
              </div>
            </div>
            <div className="vault-card rounded-2xl overflow-hidden">
              <pre className="p-6 text-sm overflow-x-auto whitespace-pre-wrap" style={{ fontFamily: "var(--font-mono)" }}>
                {systemPrompt}
              </pre>
            </div>
          </motion.div>
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="vault-card rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4">API Keys</h2>
              <p className="text-vault-text-dim text-sm mb-4">Add your API keys to use the chat feature. Keys are stored locally in your vault.</p>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">OpenAI API Key</label>
                  <input
                    type="password"
                    value={vault.apiKeys.openai || ""}
                    onChange={e => updateVault({ apiKeys: { ...vault.apiKeys, openai: e.target.value } })}
                    placeholder="sk-..."
                    className="vault-input w-full px-3 py-2 rounded-lg font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm text-vault-text-dim mb-1">Anthropic API Key</label>
                  <input
                    type="password"
                    value={vault.apiKeys.anthropic || ""}
                    onChange={e => updateVault({ apiKeys: { ...vault.apiKeys, anthropic: e.target.value } })}
                    placeholder="sk-ant-..."
                    className="vault-input w-full px-3 py-2 rounded-lg font-mono text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="vault-card rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4">Default Model</h2>
              <select
                value={vault.modelPreferences.defaultModel}
                onChange={e => updateVault({ modelPreferences: { ...vault.modelPreferences, defaultModel: e.target.value as ModelType } })}
                className="vault-input w-full px-3 py-2 rounded-lg"
              >
                {Object.entries(MODEL_INFO).map(([key, info]) => (
                  <option key={key} value={key}>{info.name} — {info.description}</option>
                ))}
              </select>
            </div>

            <div className="vault-card rounded-2xl p-6">
              <h2 className="text-lg font-semibold mb-4">Export & Import</h2>
              <div className="flex gap-3">
                <button onClick={() => exportVault(vault)} className="vault-btn-secondary px-4 py-2 rounded-lg text-sm">
                  Export Vault
                </button>
              </div>
            </div>

            <div className="vault-card rounded-2xl p-6 border-red-500/20">
              <h2 className="text-lg font-semibold mb-4 text-red-400">Danger Zone</h2>
              <button
                onClick={() => {
                  if (confirm("Are you sure? This will delete all your vault data.")) {
                    clearVault();
                    router.push("/");
                  }
                }}
                className="vault-btn-danger px-4 py-2 rounded-lg text-sm"
              >
                Delete Vault
              </button>
            </div>
          </motion.div>
        )}
      </div>

      {/* Add Memory Modal */}
      <Modal show={showAddMemory} onClose={() => setShowAddMemory(false)} title="Add Memory">
        <AddMemoryForm onAdd={(content, category, importance) => { addMemory(content, category, importance); setShowAddMemory(false); }} />
      </Modal>

      {/* Add Project Modal */}
      <Modal show={showAddProject} onClose={() => setShowAddProject(false)} title="Add Project">
        <AddProjectForm onAdd={(project) => { addProject(project); setShowAddProject(false); }} />
      </Modal>

      {/* Add Person Modal */}
      <Modal show={showAddPerson} onClose={() => setShowAddPerson(false)} title="Add Person">
        <AddPersonForm onAdd={(person) => { addPerson(person); setShowAddPerson(false); }} />
      </Modal>
    </main>
  );
}

// Modal Component
function Modal({ show, onClose, title, children }: { show: boolean; onClose: () => void; title: string; children: React.ReactNode }) {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="vault-card rounded-2xl p-6 w-full max-w-md relative z-10">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="text-vault-text-dim hover:text-vault-text">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

// Add Memory Form
function AddMemoryForm({ onAdd }: { onAdd: (content: string, category: MemoryCategory, importance: "high" | "medium" | "low") => void }) {
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<MemoryCategory>("fact");
  const [importance, setImportance] = useState<"high" | "medium" | "low">("medium");

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-vault-text-dim mb-1">What do you want to remember?</label>
        <textarea value={content} onChange={e => setContent(e.target.value)} rows={3} className="vault-input w-full px-3 py-2 rounded-lg resize-none" placeholder="e.g., I prefer TypeScript over JavaScript" autoFocus />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm text-vault-text-dim mb-1">Category</label>
          <select value={category} onChange={e => setCategory(e.target.value as MemoryCategory)} className="vault-input w-full px-3 py-2 rounded-lg">
            <option value="preference">Preference</option>
            <option value="fact">Fact</option>
            <option value="goal">Goal</option>
            <option value="constraint">Constraint</option>
            <option value="context">Context</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div>
          <label className="block text-sm text-vault-text-dim mb-1">Importance</label>
          <select value={importance} onChange={e => setImportance(e.target.value as any)} className="vault-input w-full px-3 py-2 rounded-lg">
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>
      <button onClick={() => content && onAdd(content, category, importance)} disabled={!content} className="vault-btn w-full py-2 rounded-lg disabled:opacity-50">
        Add Memory
      </button>
    </div>
  );
}

// Add Project Form
function AddProjectForm({ onAdd }: { onAdd: (project: Omit<Project, "id" | "createdAt" | "updatedAt">) => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<Project["status"]>("active");
  const [priority, setPriority] = useState<Project["priority"]>("medium");

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-vault-text-dim mb-1">Project Name</label>
        <input type="text" value={name} onChange={e => setName(e.target.value)} className="vault-input w-full px-3 py-2 rounded-lg" placeholder="e.g., Preference Vault" autoFocus />
      </div>
      <div>
        <label className="block text-sm text-vault-text-dim mb-1">Description</label>
        <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} className="vault-input w-full px-3 py-2 rounded-lg resize-none" placeholder="What is this project about?" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm text-vault-text-dim mb-1">Status</label>
          <select value={status} onChange={e => setStatus(e.target.value as any)} className="vault-input w-full px-3 py-2 rounded-lg">
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="idea">Idea</option>
            <option value="completed">Completed</option>
          </select>
        </div>
        <div>
          <label className="block text-sm text-vault-text-dim mb-1">Priority</label>
          <select value={priority} onChange={e => setPriority(e.target.value as any)} className="vault-input w-full px-3 py-2 rounded-lg">
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>
      <button onClick={() => name && onAdd({ name, description, status, priority, goals: [], notes: "" })} disabled={!name} className="vault-btn w-full py-2 rounded-lg disabled:opacity-50">
        Add Project
      </button>
    </div>
  );
}

// Add Person Form
function AddPersonForm({ onAdd }: { onAdd: (person: Omit<Person, "id" | "createdAt">) => void }) {
  const [name, setName] = useState("");
  const [relationship, setRelationship] = useState("");
  const [context, setContext] = useState("");

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-vault-text-dim mb-1">Name</label>
        <input type="text" value={name} onChange={e => setName(e.target.value)} className="vault-input w-full px-3 py-2 rounded-lg" placeholder="e.g., Sarah" autoFocus />
      </div>
      <div>
        <label className="block text-sm text-vault-text-dim mb-1">Relationship</label>
        <input type="text" value={relationship} onChange={e => setRelationship(e.target.value)} className="vault-input w-full px-3 py-2 rounded-lg" placeholder="e.g., Cofounder, Manager, Friend" />
      </div>
      <div>
        <label className="block text-sm text-vault-text-dim mb-1">Context</label>
        <textarea value={context} onChange={e => setContext(e.target.value)} rows={2} className="vault-input w-full px-3 py-2 rounded-lg resize-none" placeholder="What should AI know about this person?" />
      </div>
      <button onClick={() => name && onAdd({ name, relationship, context, communication: "" })} disabled={!name} className="vault-btn w-full py-2 rounded-lg disabled:opacity-50">
        Add Person
      </button>
    </div>
  );
}
