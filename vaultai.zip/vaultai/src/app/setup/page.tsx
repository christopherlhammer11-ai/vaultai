"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { VaultV2, defaultVault, generateId } from "@/lib/types";
import { saveVault } from "@/lib/storage";

type SetupStep = "welcome" | "identity" | "behavior" | "encryption" | "complete";

export default function SetupPage() {
  const router = useRouter();
  const [step, setStep] = useState<SetupStep>("welcome");
  const [vault, setVault] = useState<VaultV2>({
    ...defaultVault,
    createdAt: new Date().toISOString(),
  });
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [useEncryption, setUseEncryption] = useState(true);

  const updateVault = (updates: Partial<VaultV2>) => {
    setVault(prev => ({ ...prev, ...updates }));
  };

  const updateIdentity = (updates: Partial<VaultV2["identity"]>) => {
    setVault(prev => ({ ...prev, identity: { ...prev.identity, ...updates } }));
  };

  const updateBehavior = (updates: Partial<VaultV2["behavior"]>) => {
    setVault(prev => ({ ...prev, behavior: { ...prev.behavior, ...updates } }));
  };

  const handleComplete = () => {
    if (useEncryption && password !== confirmPassword) {
      alert("Passwords don't match");
      return;
    }

    // Add a welcome memory
    const welcomeMemory = {
      id: generateId(),
      content: `Vault created for ${vault.identity.name || "user"}`,
      category: "context" as const,
      importance: "medium" as const,
      createdAt: new Date().toISOString(),
      source: "setup",
    };

    const finalVault: VaultV2 = {
      ...vault,
      memories: [welcomeMemory],
      isEncrypted: useEncryption,
    };

    saveVault(finalVault, useEncryption ? password : undefined);
    setStep("complete");

    setTimeout(() => {
      router.push("/vault");
    }, 1500);
  };

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-lg">
        {/* Welcome */}
        {step === "welcome" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="w-16 h-16 rounded-2xl bg-vault-surface border border-vault-border flex items-center justify-center mx-auto mb-6">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-vault-accent">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0110 0v4" />
              </svg>
            </div>
            <h1 className="text-3xl font-bold mb-4">Create Your Vault</h1>
            <p className="text-vault-text-dim mb-8">
              Set up your personal AI vault in a few simple steps. Your data stays on your device, encrypted and private.
            </p>
            <button onClick={() => setStep("identity")} className="vault-btn px-8 py-4 rounded-xl text-lg">
              Let's Start
            </button>
          </motion.div>
        )}

        {/* Identity */}
        {step === "identity" && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <div className="text-sm text-vault-accent mb-2">Step 1 of 3</div>
            <h1 className="text-2xl font-bold mb-2">Who are you?</h1>
            <p className="text-vault-text-dim mb-8">Basic info helps AI understand your context.</p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Your name</label>
                <input
                  type="text"
                  value={vault.identity.name}
                  onChange={e => updateIdentity({ name: e.target.value })}
                  placeholder="What should AI call you?"
                  className="vault-input w-full px-4 py-3 rounded-xl"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">What do you do?</label>
                <input
                  type="text"
                  value={vault.identity.role}
                  onChange={e => updateIdentity({ role: e.target.value })}
                  placeholder="e.g., Founder, Engineer, Designer"
                  className="vault-input w-full px-4 py-3 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Company (optional)</label>
                <input
                  type="text"
                  value={vault.identity.company || ""}
                  onChange={e => updateIdentity({ company: e.target.value })}
                  placeholder="Where do you work?"
                  className="vault-input w-full px-4 py-3 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">One sentence about you</label>
                <textarea
                  value={vault.identity.bio}
                  onChange={e => updateIdentity({ bio: e.target.value })}
                  placeholder="What should AI know about you?"
                  rows={2}
                  className="vault-input w-full px-4 py-3 rounded-xl resize-none"
                />
              </div>
            </div>

            <div className="flex justify-between mt-8">
              <button onClick={() => setStep("welcome")} className="vault-btn-secondary px-6 py-3 rounded-xl">
                Back
              </button>
              <button onClick={() => setStep("behavior")} className="vault-btn px-6 py-3 rounded-xl">
                Continue
              </button>
            </div>
          </motion.div>
        )}

        {/* Behavior */}
        {step === "behavior" && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <div className="text-sm text-vault-accent mb-2">Step 2 of 3</div>
            <h1 className="text-2xl font-bold mb-2">How should AI respond?</h1>
            <p className="text-vault-text-dim mb-8">Set your default preferences.</p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Response style</label>
                <select
                  value={vault.behavior.answerMode}
                  onChange={e => updateBehavior({ answerMode: e.target.value as any })}
                  className="vault-input w-full px-4 py-3 rounded-xl"
                >
                  <option value="short">Short and direct</option>
                  <option value="steps">Step-by-step</option>
                  <option value="deep">Deep explanations</option>
                  <option value="adaptive">Adaptive to task</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Tone</label>
                <select
                  value={vault.behavior.tone}
                  onChange={e => updateBehavior({ tone: e.target.value as any })}
                  className="vault-input w-full px-4 py-3 rounded-xl"
                >
                  <option value="direct">Direct — no fluff</option>
                  <option value="friendly">Friendly — warm but professional</option>
                  <option value="formal">Formal — structured</option>
                  <option value="playful">Playful — casual and creative</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">When something is unclear</label>
                <select
                  value={vault.behavior.ambiguityPolicy}
                  onChange={e => updateBehavior({ ambiguityPolicy: e.target.value as any })}
                  className="vault-input w-full px-4 py-3 rounded-xl"
                >
                  <option value="ask">Ask me first</option>
                  <option value="assume">Make a reasonable assumption</option>
                  <option value="options">Show me 2-3 options</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Definition of success</label>
                <textarea
                  value={vault.success.definition}
                  onChange={e => updateVault({ success: { ...vault.success, definition: e.target.value } })}
                  placeholder="What should AI do better than anything else for you?"
                  rows={2}
                  className="vault-input w-full px-4 py-3 rounded-xl resize-none"
                />
              </div>
            </div>

            <div className="flex justify-between mt-8">
              <button onClick={() => setStep("identity")} className="vault-btn-secondary px-6 py-3 rounded-xl">
                Back
              </button>
              <button onClick={() => setStep("encryption")} className="vault-btn px-6 py-3 rounded-xl">
                Continue
              </button>
            </div>
          </motion.div>
        )}

        {/* Encryption */}
        {step === "encryption" && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <div className="text-sm text-vault-accent mb-2">Step 3 of 3</div>
            <h1 className="text-2xl font-bold mb-2">Protect your vault</h1>
            <p className="text-vault-text-dim mb-8">Encrypt your data with a password.</p>

            <div className="vault-card rounded-xl p-4 mb-6">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={useEncryption}
                  onChange={e => setUseEncryption(e.target.checked)}
                  className="w-5 h-5 rounded border-vault-border bg-vault-surface text-vault-accent"
                />
                <div>
                  <div className="font-medium">Enable encryption</div>
                  <div className="text-sm text-vault-text-dim">Protect your vault with AES-256 encryption</div>
                </div>
              </label>
            </div>

            {useEncryption && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Choose a strong password"
                    className="vault-input w-full px-4 py-3 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Confirm password</label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    placeholder="Type it again"
                    className="vault-input w-full px-4 py-3 rounded-xl"
                  />
                  {password && confirmPassword && password !== confirmPassword && (
                    <p className="text-red-400 text-sm mt-2">Passwords don't match</p>
                  )}
                </div>

                <p className="text-vault-text-dim text-sm">
                  ⚠️ If you forget your password, your vault cannot be recovered.
                </p>
              </div>
            )}

            <div className="flex justify-between mt-8">
              <button onClick={() => setStep("behavior")} className="vault-btn-secondary px-6 py-3 rounded-xl">
                Back
              </button>
              <button
                onClick={handleComplete}
                disabled={useEncryption && (!password || password !== confirmPassword)}
                className="vault-btn px-6 py-3 rounded-xl disabled:opacity-50"
              >
                Create Vault
              </button>
            </div>
          </motion.div>
        )}

        {/* Complete */}
        {step === "complete" && (
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center">
            <div className="w-20 h-20 rounded-full bg-vault-accent/20 flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-vault-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h1 className="text-3xl font-bold mb-2">Vault Created!</h1>
            <p className="text-vault-text-dim">
              {useEncryption ? "Your encrypted vault is ready." : "Your vault is ready."}
            </p>
          </motion.div>
        )}
      </div>
    </main>
  );
}
