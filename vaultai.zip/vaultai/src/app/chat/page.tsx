"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { VaultV2, ModelType, MODEL_INFO, hasOwnApiKey, canUseModel } from "@/lib/types";
import { loadVault, getStorageState, saveVault } from "@/lib/storage";
import { generateSystemPrompt } from "@/lib/prompt";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  model?: ModelType;
  timestamp: Date;
  usingVaultAIKey?: boolean;
}

export default function ChatPage() {
  const router = useRouter();
  const [vault, setVault] = useState<VaultV2 | null>(null);
  const [isLocked, setIsLocked] = useState(false);
  const [password, setPassword] = useState("");
  const [unlockError, setUnlockError] = useState(false);

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<ModelType>("claude-sonnet");
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const state = getStorageState();
    if (!state.hasVault) {
      router.push("/setup");
      return;
    }
    if (state.isEncrypted) {
      setIsLocked(true);
    } else {
      const loaded = loadVault();
      if (loaded) {
        setVault(loaded);
        setSelectedModel(loaded.modelPreferences.defaultModel);
      }
    }
  }, [router]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleUnlock = () => {
    const loaded = loadVault(password);
    if (loaded) {
      setVault(loaded);
      setSelectedModel(loaded.modelPreferences.defaultModel);
      setIsLocked(false);
    } else {
      setUnlockError(true);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || !vault || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    setError(null);

    const modelInfo = MODEL_INFO[selectedModel];
    const hasOwnKey = hasOwnApiKey(vault, modelInfo.provider);
    const useVaultAIKeys = !hasOwnKey; // Use VaultAI keys if user doesn't have their own

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage].map(m => ({ role: m.role, content: m.content })),
          model: selectedModel,
          apiKeys: vault.apiKeys,
          systemPrompt: generateSystemPrompt(vault),
          useVaultAIKeys,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to get response");
      }

      // Update usage if using VaultAI keys
      if (data.usingVaultAIKey && vault.subscription.tier === "free") {
        const updatedVault = {
          ...vault,
          subscription: {
            ...vault.subscription,
            usageThisMonth: vault.subscription.usageThisMonth + 1,
          },
        };
        setVault(updatedVault);
        // Save updated usage (need password if encrypted)
        const state = getStorageState();
        saveVault(updatedVault, state.isEncrypted ? password : undefined);
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.content,
        model: selectedModel,
        timestamp: new Date(),
        usingVaultAIKey: data.usingVaultAIKey,
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Lock screen
  if (isLocked) {
    return (
      <main className="lock-screen min-h-screen flex items-center justify-center px-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm text-center">
          <div className="w-16 h-16 rounded-2xl bg-vault-surface border border-vault-border flex items-center justify-center mx-auto mb-6">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-vault-accent">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0110 0v4" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold mb-2">Vault Locked</h1>
          <p className="text-vault-text-dim mb-6">Enter your password to chat</p>
          <input
            type="password"
            value={password}
            onChange={e => { setPassword(e.target.value); setUnlockError(false); }}
            onKeyDown={e => e.key === "Enter" && handleUnlock()}
            placeholder="Password"
            className="vault-input w-full px-4 py-3 rounded-xl mb-4"
            autoFocus
          />
          {unlockError && <p className="text-red-400 text-sm mb-4">Incorrect password</p>}
          <button onClick={handleUnlock} className="vault-btn w-full py-3 rounded-xl">Unlock</button>
        </motion.div>
      </main>
    );
  }

  if (!vault) {
    return <main className="min-h-screen flex items-center justify-center"><div className="spinner w-8 h-8" /></main>;
  }

  const modelInfo = MODEL_INFO[selectedModel];
  const hasOwnKey = hasOwnApiKey(vault, modelInfo.provider);
  const canUse = canUseModel(vault, selectedModel);

  return (
    <main className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="px-6 py-4 border-b border-vault-border bg-vault-bg/95 backdrop-blur-lg z-40">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <Link href="/vault" className="flex items-center gap-2 text-vault-text-dim hover:text-vault-text transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back to Vault</span>
          </Link>

          <div className="flex items-center gap-3">
            {/* Model Picker */}
            <div className="relative">
              <button
                onClick={() => setShowModelPicker(!showModelPicker)}
                className="vault-btn-secondary px-4 py-2 rounded-lg text-sm flex items-center gap-2"
              >
                <span className={`w-2 h-2 rounded-full ${canUse ? "bg-vault-accent" : "bg-vault-error"}`} />
                {modelInfo.name}
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {showModelPicker && (
                <div className="absolute right-0 mt-2 w-72 vault-card rounded-xl p-2 z-50 shadow-xl">
                  {Object.entries(MODEL_INFO).map(([key, info]) => {
                    const hasKey = hasOwnApiKey(vault, info.provider);
                    const available = canUseModel(vault, key as ModelType);
                    return (
                      <button
                        key={key}
                        onClick={() => { setSelectedModel(key as ModelType); setShowModelPicker(false); }}
                        disabled={!available}
                        className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                          selectedModel === key ? "bg-vault-accent/10 text-vault-accent" : 
                          available ? "hover:bg-vault-surface" : "opacity-50 cursor-not-allowed"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{info.name}</span>
                          <div className="flex items-center gap-2">
                            {hasKey && (
                              <span className="text-xs text-vault-accent">Your key</span>
                            )}
                            {!hasKey && info.tier === "pro" && (
                              <span className="text-xs text-vault-warning">Pro only</span>
                            )}
                            {!hasKey && info.tier !== "pro" && (
                              <span className="text-xs text-vault-text-muted">VaultAI key</span>
                            )}
                          </div>
                        </div>
                        <div className="text-xs text-vault-text-dim">{info.description}</div>
                      </button>
                    );
                  })}
                  <div className="border-t border-vault-border mt-2 pt-2 px-3">
                    <Link href="/vault" className="text-xs text-vault-accent hover:underline">
                      Add your own API keys →
                    </Link>
                  </div>
                </div>
              )}
            </div>

            <button onClick={() => setMessages([])} className="text-vault-text-dim hover:text-vault-text p-2" title="Clear chat">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-20">
              <div className="w-16 h-16 rounded-2xl bg-vault-surface border border-vault-border flex items-center justify-center mx-auto mb-4">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-vault-accent">
                  <path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <h2 className="text-xl font-semibold mb-2">Chat with VaultAI</h2>
              <p className="text-vault-text-dim max-w-md mx-auto">
                {vault.identity.name ? `Hi ${vault.identity.name}! ` : ""}
                Your vault context is automatically included. Using {modelInfo.name}.
              </p>
              {!hasOwnKey && (
                <p className="text-vault-text-muted text-sm mt-4">
                  Using VaultAI's API key • <Link href="/vault" className="text-vault-accent hover:underline">Add your own</Link>
                </p>
              )}
            </div>
          )}

          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                message.role === "user" ? "chat-user" : "chat-assistant"
              }`}>
                {message.role === "assistant" && message.model && (
                  <div className="text-xs text-vault-text-muted mb-1 flex items-center gap-2">
                    {MODEL_INFO[message.model].name}
                    {message.usingVaultAIKey && (
                      <span className="text-vault-accent">• VaultAI key</span>
                    )}
                  </div>
                )}
                <div className="whitespace-pre-wrap">{message.content}</div>
              </div>
            </motion.div>
          ))}

          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
              <div className="chat-assistant rounded-2xl px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="spinner w-4 h-4" />
                  <span className="text-vault-text-dim">Thinking...</span>
                </div>
              </div>
            </motion.div>
          )}

          {error && (
            <div className="text-center py-4">
              <p className="text-red-400 text-sm">{error}</p>
              {error.includes("API key") && (
                <Link href="/vault" className="text-vault-accent text-sm hover:underline mt-2 block">
                  Add API key in Settings →
                </Link>
              )}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-vault-border px-6 py-4 bg-vault-bg">
        <div className="max-w-4xl mx-auto">
          <div className="flex gap-3">
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              disabled={isLoading}
              rows={1}
              className="vault-input flex-1 px-4 py-3 rounded-xl resize-none disabled:opacity-50"
              style={{ minHeight: "48px", maxHeight: "200px" }}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || isLoading}
              className="vault-btn px-6 py-3 rounded-xl disabled:opacity-50"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
          <p className="text-xs text-vault-text-muted mt-2 text-center">
            Your vault context ({vault.memories.length} memories, {vault.projects.length} projects) is included with every message.
          </p>
        </div>
      </div>
    </main>
  );
}
