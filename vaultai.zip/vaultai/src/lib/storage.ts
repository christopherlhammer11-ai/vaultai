import { VaultV2, defaultVault } from "./types";
import { encryptVault, decryptVault, isEncrypted, hashPassword } from "./encryption";

const STORAGE_KEY = "preference_vault_v2";
const PASSWORD_HASH_KEY = "preference_vault_password_hash";

export interface StorageState {
  isLocked: boolean;
  isEncrypted: boolean;
  hasVault: boolean;
}

/**
 * Check the current state of vault storage
 */
export function getStorageState(): StorageState {
  if (typeof window === "undefined") {
    return { isLocked: false, isEncrypted: false, hasVault: false };
  }

  const stored = localStorage.getItem(STORAGE_KEY);
  const hasPasswordHash = localStorage.getItem(PASSWORD_HASH_KEY) !== null;

  return {
    isLocked: hasPasswordHash,
    isEncrypted: stored ? isEncrypted(stored) : false,
    hasVault: stored !== null,
  };
}

/**
 * Load vault from localStorage (unencrypted or already unlocked)
 */
export function loadVault(password?: string): VaultV2 | null {
  if (typeof window === "undefined") return defaultVault;

  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return defaultVault;

    if (isEncrypted(stored)) {
      if (!password) return null; // Need password
      return decryptVault(stored, password);
    }

    return JSON.parse(stored) as VaultV2;
  } catch (error) {
    console.error("Failed to load vault:", error);
    return null;
  }
}

/**
 * Save vault to localStorage
 */
export function saveVault(vault: VaultV2, password?: string): void {
  if (typeof window === "undefined") return;

  const updated: VaultV2 = {
    ...vault,
    updatedAt: new Date().toISOString(),
    isEncrypted: !!password,
  };

  if (password) {
    const encrypted = encryptVault(updated, password);
    localStorage.setItem(STORAGE_KEY, encrypted);
    localStorage.setItem(PASSWORD_HASH_KEY, hashPassword(password));
  } else {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated, null, 2));
    localStorage.removeItem(PASSWORD_HASH_KEY);
  }
}

/**
 * Set up encryption for an existing vault
 */
export function enableEncryption(vault: VaultV2, password: string): void {
  saveVault(vault, password);
}

/**
 * Remove encryption from vault
 */
export function disableEncryption(vault: VaultV2): void {
  saveVault(vault);
}

/**
 * Verify if a password is correct
 */
export function verifyVaultPassword(password: string): boolean {
  if (typeof window === "undefined") return false;

  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored || !isEncrypted(stored)) return true;

  const vault = decryptVault(stored, password);
  return vault !== null;
}

/**
 * Export vault as downloadable JSON (decrypted)
 */
export function exportVault(vault: VaultV2): void {
  // Remove API keys from export for security
  const exportData: VaultV2 = {
    ...vault,
    apiKeys: {},
  };

  const blob = new Blob([JSON.stringify(exportData, null, 2)], {
    type: "application/json",
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `preference-vault-${new Date().toISOString().split("T")[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Import vault from JSON file
 */
export async function importVault(file: File): Promise<{ success: boolean; vault?: VaultV2; error?: string }> {
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);

    if (!parsed || typeof parsed !== "object") {
      return { success: false, error: "Invalid JSON structure" };
    }

    // Basic validation
    if (parsed.version !== "2.0") {
      // Attempt migration from older versions
      const migrated = migrateVault(parsed);
      return { success: true, vault: migrated };
    }

    return { success: true, vault: parsed as VaultV2 };
  } catch (error) {
    return { success: false, error: "Failed to parse JSON file" };
  }
}

/**
 * Migrate from older vault versions
 */
function migrateVault(old: any): VaultV2 {
  const migrated: VaultV2 = { ...defaultVault };

  // Copy over compatible fields
  if (old.identity) migrated.identity = { ...migrated.identity, ...old.identity };
  if (old.behavior) migrated.behavior = { ...migrated.behavior, ...old.behavior };
  if (old.context) {
    migrated.context.roles = old.context.roles || [];
    migrated.context.constraints = old.context.constraints || [];
  }
  if (old.boundaries) migrated.boundaries = { ...migrated.boundaries, ...old.boundaries };
  if (old.success) migrated.success = { ...migrated.success, ...old.success };

  migrated.createdAt = old.createdAt || new Date().toISOString();
  migrated.updatedAt = new Date().toISOString();

  return migrated;
}

/**
 * Clear vault from storage
 */
export function clearVault(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(STORAGE_KEY);
  localStorage.removeItem(PASSWORD_HASH_KEY);
}

/**
 * Check if a vault exists in storage
 */
export function hasExistingVault(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(STORAGE_KEY) !== null;
}
