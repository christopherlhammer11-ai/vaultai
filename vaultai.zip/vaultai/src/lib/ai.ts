import type { VaultV2, ModelType } from "./types";
import { generateSystemPrompt } from "./prompt";

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface ChatResponse {
  content: string;
  model: ModelType;
  tokensUsed?: number;
  error?: string;
}

/**
 * Send a message to the selected AI model with vault context
 */
export async function sendMessage(
  messages: ChatMessage[],
  vault: VaultV2,
  model?: ModelType
): Promise<ChatResponse> {
  const selectedModel = model || vault.modelPreferences.defaultModel;
  const systemPrompt = generateSystemPrompt(vault);

  // Add system prompt to messages
  const fullMessages: ChatMessage[] = [
    { role: "system", content: systemPrompt },
    ...messages,
  ];

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: fullMessages,
        model: selectedModel,
        apiKeys: vault.apiKeys,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      return {
        content: "",
        model: selectedModel,
        error: error.message || "Failed to get response",
      };
    }

    const data = await response.json();
    return {
      content: data.content,
      model: selectedModel,
      tokensUsed: data.tokensUsed,
    };
  } catch (error) {
    return {
      content: "",
      model: selectedModel,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Send the same message to multiple models for comparison
 */
export async function compareModels(
  messages: ChatMessage[],
  vault: VaultV2,
  models: ModelType[]
): Promise<Record<ModelType, ChatResponse>> {
  const results: Record<string, ChatResponse> = {};

  await Promise.all(
    models.map(async (model) => {
      results[model] = await sendMessage(messages, vault, model);
    })
  );

  return results as Record<ModelType, ChatResponse>;
}

/**
 * Test if an API key is valid
 */
export async function testApiKey(
  provider: "openai" | "anthropic",
  apiKey: string
): Promise<{ valid: boolean; error?: string }> {
  try {
    const response = await fetch("/api/test-key", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ provider, apiKey }),
    });

    const data = await response.json();
    return { valid: data.valid, error: data.error };
  } catch (error) {
    return { valid: false, error: "Failed to test API key" };
  }
}
