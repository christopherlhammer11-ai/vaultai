import CryptoJS from "crypto-js";
import type { VaultV2 } from "./types";

const ENCRYPTION_PREFIX = "VAULT_ENCRYPTED:";

/**
 * Encrypts the vault data with AES-256 using the provided password
 */
export function encryptVault(vault: VaultV2, password: string): string {
  const vaultJson = JSON.stringify(vault);
  const encrypted = CryptoJS.AES.encrypt(vaultJson, password).toString();
  return ENCRYPTION_PREFIX + encrypted;
}

/**
 * Decrypts the vault data using the provided password
 */
export function decryptVault(encryptedData: string, password: string): VaultV2 | null {
  try {
    if (!encryptedData.startsWith(ENCRYPTION_PREFIX)) {
      // Not encrypted, try to parse as JSON
      return JSON.parse(encryptedData) as VaultV2;
    }

    const encrypted = encryptedData.slice(ENCRYPTION_PREFIX.length);
    const decrypted = CryptoJS.AES.decrypt(encrypted, password);
    const decryptedString = decrypted.toString(CryptoJS.enc.Utf8);

    if (!decryptedString) {
      return null; // Wrong password
    }

    return JSON.parse(decryptedString) as VaultV2;
  } catch (error) {
    console.error("Decryption failed:", error);
    return null;
  }
}

/**
 * Checks if stored data is encrypted
 */
export function isEncrypted(data: string): boolean {
  return data.startsWith(ENCRYPTION_PREFIX);
}

/**
 * Encrypts a single sensitive field
 */
export function encryptField(value: string, password: string): string {
  return CryptoJS.AES.encrypt(value, password).toString();
}

/**
 * Decrypts a single sensitive field
 */
export function decryptField(encryptedValue: string, password: string): string | null {
  try {
    const decrypted = CryptoJS.AES.decrypt(encryptedValue, password);
    return decrypted.toString(CryptoJS.enc.Utf8) || null;
  } catch {
    return null;
  }
}

/**
 * Hashes a password for verification (not for encryption)
 */
export function hashPassword(password: string): string {
  return CryptoJS.SHA256(password).toString();
}

/**
 * Verifies a password against a hash
 */
export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

/**
 * Generates a random encryption key (for future use with key derivation)
 */
export function generateKey(): string {
  return CryptoJS.lib.WordArray.random(32).toString();
}
