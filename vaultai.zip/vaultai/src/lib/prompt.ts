import type { VaultV2, Memory, Project, Person } from "./types";

/**
 * Generates a comprehensive system prompt from the vault data
 */
export function generateSystemPrompt(vault: VaultV2): string {
  const sections: string[] = [];

  // Opening
  sections.push("You are a personalized AI assistant with deep knowledge of this user.");
  sections.push("");

  // Identity context
  const identityParts: string[] = [];
  if (vault.identity.name) identityParts.push(`Name: ${vault.identity.name}`);
  if (vault.identity.role) identityParts.push(`Role: ${vault.identity.role}`);
  if (vault.identity.company) identityParts.push(`Company: ${vault.identity.company}`);
  if (vault.identity.bio) identityParts.push(`About: ${vault.identity.bio}`);
  if (vault.identity.location) identityParts.push(`Location: ${vault.identity.location}`);
  if (vault.identity.timezone) identityParts.push(`Timezone: ${vault.identity.timezone}`);

  if (identityParts.length > 0) {
    sections.push("## User Identity");
    identityParts.forEach(p => sections.push(`- ${p}`));
    sections.push("");
  }

  // Behavior guidelines
  sections.push("## Communication Style");
  
  const answerModeMap: Record<string, string> = {
    short: "Keep responses concise and direct. Get to the point quickly.",
    steps: "Break down responses into clear steps. Walk through the reasoning.",
    deep: "Provide thorough explanations with context and nuance.",
    adaptive: "Match response depth to task complexity.",
  };
  sections.push(`- ${answerModeMap[vault.behavior.answerMode]}`);

  const toneMap: Record<string, string> = {
    direct: "Use a direct, no-nonsense tone. Skip filler.",
    friendly: "Use a warm, friendly tone while staying professional.",
    formal: "Use a formal, structured tone.",
    playful: "Use a casual, creative tone.",
  };
  sections.push(`- ${toneMap[vault.behavior.tone]}`);

  const ambiguityMap: Record<string, string> = {
    ask: "If unclear, ask for clarification before proceeding.",
    assume: "If unclear, make a reasonable assumption and note it.",
    options: "If unclear, present 2-3 interpretations to choose from.",
  };
  sections.push(`- ${ambiguityMap[vault.behavior.ambiguityPolicy]}`);

  const riskMap: Record<string, string> = {
    clear_pushback: "Push back clearly on risky ideas with alternatives.",
    light_warning: "Note risks briefly, then continue.",
    danger_only: "Only push back if genuinely dangerous.",
  };
  sections.push(`- ${riskMap[vault.behavior.riskPushback]}`);

  sections.push("");

  // Context & skills
  if (vault.context.roles.length > 0 || vault.context.skills.length > 0 || vault.context.industries.length > 0) {
    sections.push("## Professional Context");
    
    if (vault.context.roles.length > 0) {
      sections.push(`- Use cases: ${vault.context.roles.join(", ")}`);
    }
    if (vault.context.industries.length > 0) {
      sections.push(`- Industries: ${vault.context.industries.join(", ")}`);
    }
    if (vault.context.skills.length > 0) {
      sections.push(`- Skills: ${vault.context.skills.join(", ")}`);
    }
    if (vault.context.constraints.length > 0) {
      sections.push(`- Constraints: ${vault.context.constraints.join(", ")}`);
    }
    if (vault.context.interests.length > 0) {
      sections.push(`- Interests: ${vault.context.interests.join(", ")}`);
    }
    sections.push("");
  }

  // Active projects
  const activeProjects = vault.projects.filter(p => p.status === "active");
  if (activeProjects.length > 0) {
    sections.push("## Active Projects");
    activeProjects.forEach(project => {
      sections.push(`### ${project.name}`);
      sections.push(`- Status: ${project.status}, Priority: ${project.priority}`);
      if (project.description) sections.push(`- Description: ${project.description}`);
      if (project.goals.length > 0) sections.push(`- Goals: ${project.goals.join("; ")}`);
      if (project.notes) sections.push(`- Notes: ${project.notes}`);
    });
    sections.push("");
  }

  // Key people
  if (vault.people.length > 0) {
    sections.push("## Key People");
    vault.people.forEach(person => {
      sections.push(`- **${person.name}** (${person.relationship}): ${person.context}`);
    });
    sections.push("");
  }

  // Important memories
  const importantMemories = vault.memories.filter(m => m.importance === "high");
  if (importantMemories.length > 0) {
    sections.push("## Important Context");
    importantMemories.forEach(memory => {
      sections.push(`- [${memory.category}] ${memory.content}`);
    });
    sections.push("");
  }

  // Goals
  if (vault.success.definition || vault.success.currentGoals.length > 0) {
    sections.push("## Goals & Success");
    if (vault.success.definition) {
      sections.push(`Definition of success: "${vault.success.definition}"`);
    }
    if (vault.success.currentGoals.length > 0) {
      sections.push("Current goals:");
      vault.success.currentGoals.forEach(goal => sections.push(`- ${goal}`));
    }
    sections.push("");
  }

  // Privacy boundaries
  sections.push("## Privacy Rules");
  sections.push("- Never request or reveal sensitive information (passwords, SSNs, financial details, private keys).");
  if (vault.boundaries.alwaysAskBefore.length > 0) {
    sections.push(`- Always confirm before: ${vault.boundaries.alwaysAskBefore.join(", ")}`);
  }
  sections.push("");

  return sections.join("\n").trim();
}

/**
 * Generates a context-aware prompt for a specific task
 * Pulls only relevant memories, projects, and people
 */
export function generateContextualPrompt(
  vault: VaultV2,
  taskDescription: string
): string {
  const basePrompt = generateSystemPrompt(vault);
  
  // In a more advanced version, this would use embeddings to find relevant context
  // For now, we include everything
  
  return basePrompt;
}

/**
 * Generates a minimal prompt for quick interactions
 */
export function generateMinimalPrompt(vault: VaultV2): string {
  const parts: string[] = [];
  
  parts.push("You are a helpful assistant.");
  
  if (vault.identity.name) {
    parts.push(`User: ${vault.identity.name}${vault.identity.role ? ` (${vault.identity.role})` : ""}.`);
  }
  
  const toneMap: Record<string, string> = {
    direct: "Be direct and concise.",
    friendly: "Be friendly but professional.",
    formal: "Be formal and structured.",
    playful: "Be casual and creative.",
  };
  parts.push(toneMap[vault.behavior.tone]);
  
  if (vault.success.definition) {
    parts.push(`Goal: ${vault.success.definition}`);
  }
  
  return parts.join(" ");
}

/**
 * Estimates token count (rough approximation)
 */
export function estimateTokens(text: string): number {
  return Math.max(1, Math.round(text.length / 4));
}

/**
 * Formats the prompt for display with syntax highlighting hints
 */
export function formatPromptForDisplay(prompt: string): string {
  return prompt;
}
