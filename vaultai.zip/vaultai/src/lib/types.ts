// VaultAI Schema v1
// Deep personal vault with subscription tier support

export interface VaultV2 {
  version: "2.0";
  createdAt: string;
  updatedAt: string;
  isEncrypted: boolean;

  // Core identity
  identity: {
    name: string;
    role: string;
    location: string;
    timezone: string;
    bio: string;
    email?: string;
    company?: string;
  };

  // How you want AI to behave
  behavior: {
    answerMode: "short" | "steps" | "deep" | "adaptive";
    ambiguityPolicy: "ask" | "assume" | "options";
    riskPushback: "clear_pushback" | "light_warning" | "danger_only";
    explainLevel: "always" | "only_complex" | "never";
    tone: "direct" | "friendly" | "formal" | "playful";
  };

  // Context about your work and life
  context: {
    roles: string[];
    constraints: string[];
    industries: string[];
    skills: string[];
    interests: string[];
  };

  // Active projects and goals
  projects: Project[];

  // Important people in your life/work
  people: Person[];

  // Memories - things you've told the vault
  memories: Memory[];

  // Sensitive information (encrypted separately)
  sensitive: {
    financial?: string;
    health?: string;
    legal?: string;
    personal?: string;
  };

  // Privacy and security rules
  boundaries: {
    neverShare: string[];
    alwaysAskBefore: string[];
  };

  // What success looks like
  success: {
    definition: string;
    currentGoals: string[];
  };

  // User's own API keys (for free tier)
  apiKeys: {
    openai?: string;
    anthropic?: string;
  };

  // Model preferences
  modelPreferences: {
    defaultModel: ModelType;
    modelNotes: Record<string, string>;
  };

  // Subscription status
  subscription: {
    tier: "free" | "pro";
    usageThisMonth: number;
    usageLimit: number;
  };
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: "active" | "paused" | "completed" | "idea";
  priority: "high" | "medium" | "low";
  goals: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Person {
  id: string;
  name: string;
  relationship: string;
  context: string;
  communication: string;
  createdAt: string;
}

export interface Memory {
  id: string;
  content: string;
  category: MemoryCategory;
  importance: "high" | "medium" | "low";
  createdAt: string;
  source?: string;
}

export type MemoryCategory = 
  | "preference"
  | "fact"
  | "goal"
  | "constraint"
  | "context"
  | "project"
  | "person"
  | "sensitive"
  | "other";

export type ModelType = "gpt-4o" | "gpt-4o-mini" | "claude-sonnet" | "claude-haiku";

export interface ModelInfo {
  name: string;
  provider: "openai" | "anthropic";
  description: string;
  tier: "free" | "pro" | "both"; // Which tier can use this model with VaultAI keys
}

export const MODEL_INFO: Record<ModelType, ModelInfo> = {
  "gpt-4o": { 
    name: "GPT-4o", 
    provider: "openai", 
    description: "Most capable OpenAI model",
    tier: "pro"
  },
  "gpt-4o-mini": { 
    name: "GPT-4o Mini", 
    provider: "openai", 
    description: "Fast and affordable",
    tier: "both"
  },
  "claude-sonnet": { 
    name: "Claude Sonnet", 
    provider: "anthropic", 
    description: "Balanced intelligence and speed",
    tier: "both"
  },
  "claude-haiku": { 
    name: "Claude Haiku", 
    provider: "anthropic", 
    description: "Fastest Claude model",
    tier: "both"
  },
};

// Default vault for new users
export const defaultVault: VaultV2 = {
  version: "2.0",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  isEncrypted: false,
  identity: {
    name: "",
    role: "",
    location: "",
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "",
    bio: "",
  },
  behavior: {
    answerMode: "adaptive",
    ambiguityPolicy: "options",
    riskPushback: "clear_pushback",
    explainLevel: "only_complex",
    tone: "direct",
  },
  context: {
    roles: [],
    constraints: [],
    industries: [],
    skills: [],
    interests: [],
  },
  projects: [],
  people: [],
  memories: [],
  sensitive: {},
  boundaries: {
    neverShare: [
      "social security number",
      "bank account numbers",
      "credit card numbers",
      "passwords",
      "private keys",
    ],
    alwaysAskBefore: [
      "sending emails",
      "making purchases",
      "sharing personal info",
    ],
  },
  success: {
    definition: "",
    currentGoals: [],
  },
  apiKeys: {},
  modelPreferences: {
    defaultModel: "claude-sonnet",
    modelNotes: {},
  },
  subscription: {
    tier: "free",
    usageThisMonth: 0,
    usageLimit: 50, // 50 free messages/month with VaultAI keys
  },
};

// Helper to generate unique IDs
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Check if user has their own API key for a provider
export function hasOwnApiKey(vault: VaultV2, provider: "openai" | "anthropic"): boolean {
  if (provider === "openai") return !!vault.apiKeys.openai;
  if (provider === "anthropic") return !!vault.apiKeys.anthropic;
  return false;
}

// Check if user can use VaultAI's keys for a model
export function canUseVaultAIKeys(vault: VaultV2, model: ModelType): boolean {
  const info = MODEL_INFO[model];
  if (info.tier === "both") return true;
  if (info.tier === "pro" && vault.subscription.tier === "pro") return true;
  return false;
}

// Check if user can use a model (either own key or VaultAI key)
export function canUseModel(vault: VaultV2, model: ModelType): boolean {
  const info = MODEL_INFO[model];
  // Can always use with own key
  if (hasOwnApiKey(vault, info.provider)) return true;
  // Check VaultAI key eligibility
  return canUseVaultAIKeys(vault, model);
}
